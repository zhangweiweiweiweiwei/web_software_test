import time
import unittest

from parameterized import parameterized
from selenium import webdriver
from selenium.webdriver.common.by import By
from utils import get_element


# 定义测试类
class TestLogin(unittest.TestCase):
    case_data = [("13012345678","12345678","88888","验证码错误", False),
                 ("", "12345678", "8888", "用户名不能为空", False),
                 ("13012345678", "", "8888", "密码不能为空", False),
                 ("13012345678", "12345678", "", "验证码不能为空", False),
                 ("13012345678", "123456789", "8888", "密码错误", False),
                 ("18866666666", "123456789", "8888", "我的账户", True)
                 ]
    # 定义类级别fixture初始化操作
    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Chrome()
        cls.driver.get("http://tpshop-test.itheima.net/")
        cls.driver.maximize_window()

    # 定义方法级别的fixture
    def setUp(self):
        self.driver.get("http://tpshop-test.itheima.net/")

    # 定义类级别fixture销毁操作
    @classmethod
    def tearDownClass(cls):
        cls.driver.quit()

    # 定义测试方法
    # 验证码错误
    @parameterized.expand(case_data)
    def test_login_06(self, mobile, password, code, expect, is_success):
        go_login = (By.CSS_SELECTOR, ".red")  # 登录按钮的元素定位信息
        get_element(self.driver, go_login).click()
        # 输入用户名
        ele_mobile = (By.ID, "username")
        get_element(self.driver, ele_mobile).clear()
        get_element(self.driver, ele_mobile).send_keys(mobile)
        # 输入密码
        ele_password = (By.ID, "password")
        get_element(self.driver, ele_password).clear()
        get_element(self.driver, ele_password).send_keys(password)
        # 输入验证码
        ele_code = (By.ID, "verify_code")
        get_element(self.driver, ele_code).clear()
        get_element(self.driver, ele_code).send_keys(code)
        # 点击登陆
        ele_login = By.CSS_SELECTOR,".J-login-submit"
        get_element(self.driver, ele_login).click()
        time.sleep(2)
        # 判断用户是否登陆成功
        if is_success:
            msg = self.driver.title

        else:
            msg = get_element(self.driver, (By.CSS_SELECTOR, ".layui-layer-content")).text
        self.assertIn(expect, msg)
        print(msg)
        time.sleep(5)


    # 用户名为空
    # def test_login_02(self):
    #     # 进入首页，然后点击登陆超链接
    #     # driver = webdriver.Chrome()
    #     # driver.get("http://tpshop-test.itheima.net/")
    #     # driver.maximize_window()
    #     go_login = (By.CSS_SELECTOR, ".red")  # 登录按钮的元素定位信息
    #     get_element(self.driver, go_login).click()
    #     # 输入用户名
    #     ele_mobile = (By.ID, "username")
    #     get_element(self.driver, ele_mobile).clear()
    #     # get_element(driver, ele_mobile).send_keys("13012345678")
    #     # 输入密码
    #     ele_password = (By.ID, "password")
    #     get_element(self.driver, ele_password).clear()
    #     get_element(self.driver, ele_password).send_keys("12345678")
    #     # 输入验证码
    #     ele_code = (By.ID, "verify_code")
    #     get_element(self.driver, ele_code).clear()
    #     get_element(self.driver, ele_code).send_keys("8888")
    #     # 点击登陆
    #     ele_login = By.CSS_SELECTOR, ".J-login-submit"
    #     get_element(self.driver, ele_login).click()
    #     time.sleep(2)
    #     # 判断用户是否登陆成功
    #     msg = get_element(self.driver, (By.CSS_SELECTOR, ".layui-layer-content")).text
    #     self.assertIn("用户名不能为空", msg)
    #     # 退出浏览器
    #     # driver.quit()
    #
    # # 密码为空
    # def test_login_03(self):
    #     # 进入首页，然后点击登陆超链接
    #     # driver = webdriver.Chrome()
    #     # driver.get("http://tpshop-test.itheima.net/")
    #     # driver.maximize_window()
    #     go_login = (By.CSS_SELECTOR, ".red")  # 登录按钮的元素定位信息
    #     get_element(self.driver, go_login).click()
    #     # 输入用户名
    #     ele_mobile = (By.ID, "username")
    #     get_element(self.driver, ele_mobile).clear()
    #     get_element(self.driver, ele_mobile).send_keys("13012345678")
    #     # 输入密码
    #     ele_password = (By.ID, "password")
    #     get_element(self.driver, ele_password).clear()
    #     # get_element(driver, ele_password).send_keys("12345678")
    #     # 输入验证码
    #     ele_code = (By.ID, "verify_code")
    #     get_element(self.driver, ele_code).clear()
    #     get_element(self.driver, ele_code).send_keys("8888")
    #     # 点击登陆
    #     ele_login = By.CSS_SELECTOR, ".J-login-submit"
    #     get_element(self.driver, ele_login).click()
    #     time.sleep(2)
    #     # 判断用户是否登陆成功
    #     msg = get_element(self.driver, (By.CSS_SELECTOR, ".layui-layer-content")).text
    #     self.assertIn("密码不能为空", msg)
    #     # 退出浏览器
    #     # driver.quit()
    #
    # # 验证码为空
    # def test_login_04(self):
    #     # 进入首页，然后点击登陆超链接
    #     # driver = webdriver.Chrome()
    #     # driver.get("http://tpshop-test.itheima.net/")
    #     # driver.maximize_window()
    #     go_login = (By.CSS_SELECTOR, ".red")  # 登录按钮的元素定位信息
    #     get_element(self.driver, go_login).click()
    #     # 输入用户名
    #     ele_mobile = (By.ID, "username")
    #     get_element(self.driver, ele_mobile).clear()
    #     get_element(self.driver, ele_mobile).send_keys("13012345678")
    #     # 输入密码
    #     ele_password = (By.ID, "password")
    #     get_element(self.driver, ele_password).clear()
    #     get_element(self.driver, ele_password).send_keys("12345678")
    #     # 输入验证码
    #     ele_code = (By.ID, "verify_code")
    #     get_element(self.driver, ele_code).clear()
    #     # get_element(driver, ele_code).send_keys("8888")
    #     # 点击登陆
    #     ele_login = By.CSS_SELECTOR, ".J-login-submit"
    #     get_element(self.driver, ele_login).click()
    #     time.sleep(2)
    #     # 判断用户是否登陆成功
    #     msg = get_element(self.driver, (By.CSS_SELECTOR, ".layui-layer-content")).text
    #     self.assertIn("验证码不能为空", msg)
    #     # 退出浏览器
    #     # driver.quit()
    #
    # # 密码错误
    # def test_login_05(self):
    #     # 进入首页，然后点击登陆超链接
    #     # driver = webdriver.Chrome()
    #     # driver.get("http://tpshop-test.itheima.net/")
    #     # driver.maximize_window()
    #     go_login = (By.CSS_SELECTOR, ".red")  # 登录按钮的元素定位信息
    #     get_element(self.driver, go_login).click()
    #     # 输入用户名
    #     ele_mobile = (By.ID, "username")
    #     get_element(self.driver, ele_mobile).clear()
    #     get_element(self.driver, ele_mobile).send_keys("13012345678")
    #     # 输入密码
    #     ele_password = (By.ID, "password")
    #     get_element(self.driver, ele_password).clear()
    #     get_element(self.driver, ele_password).send_keys("123456789")
    #     # 输入验证码
    #     ele_code = (By.ID, "verify_code")
    #     get_element(self.driver, ele_code).clear()
    #     get_element(self.driver, ele_code).send_keys("8888")
    #     # 点击登陆
    #     ele_login = By.CSS_SELECTOR, ".J-login-submit"
    #     get_element(self.driver, ele_login).click()
    #     time.sleep(2)
    #     # 判断用户是否登陆成功
    #     msg = get_element(self.driver, (By.CSS_SELECTOR, ".layui-layer-content")).text
    #     self.assertIn("密码错误", msg)
    #     # 退出浏览器
    #     # driver.quit()
    #
    # # 登陆成功
    # def test_login_01(self):
    #     # 进入首页，然后点击登陆超链接
    #     # driver = webdriver.Chrome()
    #     # driver.get("http://tpshop-test.itheima.net/")
    #     # driver.maximize_window()
    #     go_login = (By.CSS_SELECTOR, ".red")  # 登录按钮的元素定位信息
    #     get_element(self.driver, go_login).click()
    #     # 输入用户名
    #     ele_mobile = (By.ID, "username")
    #     get_element(self.driver, ele_mobile).clear()
    #     get_element(self.driver, ele_mobile).send_keys("13012345678")
    #     # 输入密码
    #     ele_password = (By.ID, "password")
    #     get_element(self.driver, ele_password).clear()
    #     get_element(self.driver, ele_password).send_keys("12345678")
    #     # 输入验证码
    #     ele_code = (By.ID, "verify_code")
    #     get_element(self.driver, ele_code).clear()
    #     get_element(self.driver, ele_code).send_keys("88888")
    #     # 点击登陆
    #     ele_login = By.CSS_SELECTOR, ".J-login-submit"
    #     get_element(self.driver, ele_login).click()
    #     time.sleep(2)
    #     # 判断用户是否登陆成功
    #     msg = get_element(self.driver, (By.CSS_SELECTOR, ".layui-layer-content")).text
    #     self.assertIn("验证码错误", msg)
    #     # 退出浏览器
    #     # driver.quit()



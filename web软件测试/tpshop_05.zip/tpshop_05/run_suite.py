import time
import unittest
from HTMLTestRunner import HTMLTestRunner

# 定义测试套件
suite = unittest.TestLoader().discover("./test_case", pattern='test*.py')

# 定义测试报告文件的路径及名称
filename = './report/html_report_{}.html'.format(time.strftime("%Y%m%d%H%M%S"))
# 打开测试报告文件
with open(filename, 'wb') as f:
    # 实例化HTMLTestRunner
    runner = HTMLTestRunner(stream=f, title="web自动化测试", description="win10-chrome-v20")
    runner.run(suite)

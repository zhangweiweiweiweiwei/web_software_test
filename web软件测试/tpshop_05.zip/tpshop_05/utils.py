from selenium.webdriver.support.wait import WebDriverWait


def get_element(driver, location):  # location是一个元组
    wait = WebDriverWait(driver, 10, 1)
    element = wait.until(lambda x: x.find_element(*location))
    return element
